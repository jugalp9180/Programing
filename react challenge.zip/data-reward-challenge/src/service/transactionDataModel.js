

export default function() {
  return Promise.resolve(
    [
        {
          custid: 1,
          name: "ABC",
          amt: 120,
          transactionDt: "05-01-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 75,
          transactionDt: "05-21-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 94,
          transactionDt: "05-21-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 10,
          transactionDt: "06-01-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 75,
          transactionDt: "06-21-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 200,
          transactionDt: "07-01-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 1,
          transactionDt: "07-04-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 80,
          transactionDt: "07-03-2019"
        },
        {
          custid: 1,
          name: "ABC",
          amt: 224,
          transactionDt: "07-21-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 125,
          transactionDt: "05-01-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 75,
          transactionDt: "05-21-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 10,
          transactionDt: "06-01-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 75,
          transactionDt: "06-21-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 200,
          transactionDt: "07-01-2019"
        },
        {
          custid: 2,
          name: "PQR",
          amt: 224,
          transactionDt: "07-21-2019"
        },
        {
          custid: 3,
          name: "XYZ",
          amt: 120,
          transactionDt: "06-21-2019"
        }
    ]
  );
};